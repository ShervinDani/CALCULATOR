package com.example.advancedcalculator;

import androidx.appcompat.app.AppCompatActivity;
import org.mozilla.javascript.*;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{
    String str1[]=new String[100000];
    String equation="";
    String calculate="";
    String xy;

    boolean flag=false;
    ImageView img1;
    ImageView img2;
    ImageView img3;
    ImageView img4;
    ImageView img5;
    ImageView img6;
    ImageView img7;
    ImageView img8;
    ImageView img9;
    ImageView img0;
    ImageView imgdl;
    ImageView imgcl;
    ImageView imgdt;
    ImageView img00;
    ImageView imgdiv;
    ImageView imgmul;
    ImageView imgmod;
    ImageView imgeq;
    ImageView imgadd;
    ImageView imgsub;
    TextView imgres;
    TextView imgeqn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img1 = findViewById(R.id.imageView1);
        img1.setTag("1");
        img2 = findViewById(R.id.imageView2);
        img2.setTag("2");
        img3 = findViewById(R.id.imageView3);
        img3.setTag("3");
        img4 = findViewById(R.id.imageView4);
        img4.setTag("4");
        img5 = findViewById(R.id.imageView5);
        img5.setTag("5");
        img6 = findViewById(R.id.imageView6);
        img6.setTag("6");
        img7 = findViewById(R.id.imageView7);
        img7.setTag("7");
        img8 = findViewById(R.id.imageView8);
        img8.setTag("8");
        img9 = findViewById(R.id.imageView9);
        img9.setTag("9");
        img0 = findViewById(R.id.imageView0);
        img0.setTag("0");
        imgdiv = findViewById(R.id.imageViewdiv);
        imgdiv.setTag("/");
        imgmul = findViewById(R.id.imageViewmul);
        imgmul.setTag("*");
        imgmod = findViewById(R.id.imageViewmod);
        imgmod.setTag("%");
        imgadd = findViewById(R.id.imageViewadd);
        imgadd.setTag("+");
        imgsub = findViewById(R.id.imageViewsub);
        imgsub.setTag("-");
        imgdt = findViewById(R.id.imageViewdot);
        imgdt.setTag(".");
        imgdl = findViewById(R.id.imageViewdl);
        imgdl.setTag("dl");
        imgcl = findViewById(R.id.imageViewC);
        imgcl.setTag("cl");
        img00 = findViewById(R.id.imageViewb);
        img00.setTag("00");
        imgeq = findViewById(R.id.imageVieweq);
        imgeq.setTag("=");
        imgeqn = findViewById(R.id.rectangle_1);
        imgeqn.setText("0");
        imgres = findViewById(R.id.rectangle_2);
        MainActivity main=new MainActivity();
        img1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=img1.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        img2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=img2.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        img3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=img2.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        img4.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=img4.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        img5.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=img5.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        img6.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=img6.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        img7.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=img7.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        img8.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=img8.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        img9.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=img9.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        img0.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=img0.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        imgadd.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=imgadd.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        imgsub.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=imgsub.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        imgmul.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=imgmul.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        imgdiv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=imgdiv.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        img00.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=img00.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        imgdt.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=imgdt.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        imgcl.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation="";
                imgeqn.setText("0");
            }
        });
        imgdl.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                if(equation.length()>=1)
                {
                    equation=equation.substring(0,equation.length()-1);
                    imgeqn.setText(equation);
                }
                if(equation.length()==0)
                {
                    imgeqn.setText("0");
                }
            }
        });
        imgmod.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick1(v);
                equation+=imgmod.getTag().toString();
                imgeqn.setText(equation);
            }
        });
        imgeq.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                main.onClick2(v);
                imgres.setText(equation);
                equation="";
                imgeqn.setText("0");
            }
        });
    }
    public void onClick1(View view)
    {
        ImageView img=(ImageView) view;
        img.setImageResource(R.drawable.rectangle_4_ek4_shape);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                img.setImageResource(R.drawable.rectangle_1_shape);
            }
        },70);
    }
    public void onClick2(View view)
    {
        ImageView img=(ImageView) view;
        img.setImageResource(R.drawable.rectangle_1_shape);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                img.setImageResource(R.drawable.rectangle_4_ek4_shape);
            }
        },70);
    }
    public void calculate()
    {
        float textsize=imgeqn.getTextSize();
        float max=getResources().getDisplayMetrics().widthPixels;
        max*=0.86f;
        while(textsize>max)
        {
            textsize--;
        }
        imgeqn.setTextSize(textsize);
    }
}